package businesslogic.event;

public interface EventItemInfo {
}
